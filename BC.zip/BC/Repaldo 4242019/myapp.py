'''from flask import Flask
from flask import request
import os 
import zeep
import base64
import pyqrcode
from PIL import Image'''
# -*- coding: utf-8 -*-
import os
import json
import pyqrcode
import io
import base64
from PIL import Image
import time 
from requests.auth import HTTPBasicAuth
import requests
from Cryptodome.Signature import pkcs1_15
from Cryptodome.Hash import SHA256
from Cryptodome.PublicKey import RSA
from lxml import etree as ET
import platform
#import urllib2 
import zeep 
from flask import Flask, request
from flask import current_app 
from flask import Response 
from datetime import datetime
from datetime import date
from pytz import timezone
import logging

app = Flask(__name__)

@app.route("/")
def hello():
    #return 'HELLO'
    app.logger.debug('Arranque de la aplicacion')
    return 'Ejemplo para logs'
	
@app.route("/prueba")
def prueba():
    return 'ALGO'
@app.route('/QRCode')
def QRCode():
	a = request.args['a']	
	b = request.args['b']
	c = request.args['c']
	d  = request.args['d']
	e = request.args['e']

	url = 'https://verificacfdi.facturaelectronica.sat.gob.mx/default.aspx?&id='+a+'&re='+b+'&rr='+c+'&tt='+d+'&fe='+e
	c = pyqrcode.create(url)
	s = io.BytesIO()
	
	c.png(s,scale=6)
	img = s.getvalue()
	encoded = base64.b64encode(s.getvalue()).decode("ascii")
	#return encoded
	return Response (encoded, mimetype='application/json') 

	
	
@app.route('/Timbrado')
def Timbrado():
	URL = request.args['URL'] #Obtiene URL
	User= request.args['User'] #Obtiene USER
	Passw= request.args['Pass'] #Obtiene Pass
	ID= request.args['ID']		#Obtiene ID que hace Ref. Factura Historico
	User_PAC= request.args['UP']
	Password_PAC=request.args['PP']
	URL_PAC=request.args['URLP']
	Key = request.args['Key'] #Obtener la llave! desde JSON como el Certificado
	Passw = Passw.replace('PLUS','+') #Colocar en Request BC el PLUS
	
	Respuesta =  requests.get(URL+'/'+ID+'/XML', auth=HTTPBasicAuth(User, Passw), verify=False)
	
	JSON = Respuesta.json()  #Traduce a JSON
	
	parser = ET.XMLParser(recover=True,encoding='utf-8')
	xdoc = ET.fromstring(JSON['value'].encode('utf-8'),parser=parser)
	xml1 = ET.tostring(xdoc)
	

	xsl_root = ET.parse(current_app.open_resource('cadenaoriginal_3_3.xslt'))#'cadenaoriginal_3_3.xslt')
	
	xsl = ET.XSLT(xsl_root)
	cadena_original = xsl(xdoc)
	
	key = RSA.import_key(open(Key+'.pem','r').read()) #Busca el ID de la KEY se debe de cambiar por un GET/JSON
	
	string = str(cadena_original)
	string = string.replace("\n","")
	string = string.replace("\r","")
	string=string.replace('        ','')
	string= string.lstrip()
	string= string.rstrip()
	#######
	
	h = SHA256.new(string.encode("utf8"))
	
	signature = pkcs1_15.new(key).sign(h)
	
	c=base64.b64encode(signature)
	
	xdoc.attrib['Sello'] = c #Comentado para pruebas
	
	wsdl= URL_PAC#'https://www.appfacturainteligente.com/WSTimbrado33Test/WSCFDI33.svc?WSDL'
	
	client = zeep.Client(wsdl=wsdl)
	xml1 = ET.tostring(xdoc)
	'''
	xml1=xml1.replace('&#13;','')
	xml1=xml1.replace('&#10;','')
	'''
	result = client.service.TimbrarCFDI(User_PAC,Password_PAC,xml1,'Ref') #Peticion a PAC
	cad = '0'
	
	try:
	    if result.XMLResultado is not None:
	        cad = result.XMLResultado
	    else:
	        cad = result.CodigoRespuesta+'#'+result.MensajeError
	except:
	    cad = 'Algo salio mal'

	#return cad
	#return xml1
	return Response (cad, mimetype='application/json') 


@app.route('/Tiempo')
def hora():
	
	#timer = datetime.now() #timezone('Mexico/General'))
	#return timer.strftime('%H:%M:%S') 
	now = datetime.now()
	tiempo = now.strftime("%H:%M:%S")
	return Response (tiempo, mimetype='application/json')

@app.route('/Fecha')
def fecha():
	now = datetime.now()
	tiempo = now.strftime("%H:%M:%S")
	today = date.today()
	fecha = today.strftime("%Y-%m-%d")
	#timer = datetime.now() #timezone('Mexico/General'))
	#return timer.strftime('%Y-%m-%dT%H:%M:%S')
	#return fecha+'T'+tiempo
	return Response (fecha+'T'+tiempo, mimetype='application/json')