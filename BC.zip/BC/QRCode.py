# -*- coding: utf-8 -*-
import os
import json
import pyqrcode
import io
import base64
import io
from PIL import Image
import time 
from requests.auth import HTTPBasicAuth
import requests
from Cryptodome.Signature import pkcs1_15
from Cryptodome.Hash import SHA256
from Cryptodome.PublicKey import RSA
from lxml import etree as ET
import platform
import urllib2 
import zeep 
from flask import Flask, request
from flask import current_app

app = Flask(__name__) 

@app.route('/QRCode')
def QRCode():
	a = request.args['a']
	b = request.args['b']
	c = request.args['c']
	d  = request.args['d']
	e = request.args['e']
	url = 'https://verificacfdi.facturaelectronica.sat.gob.mx/default.aspx?&id='+a+'&re='+b+'&rr='+c+'&tt='+d+'&fe='+e
	c = pyqrcode.create(url)
	s = io.BytesIO()
	c.png(s,scale=6)
	img = s.getvalue()
	encoded = base64.b64encode(s.getvalue()).decode("ascii")
	return encoded

@app.route('/Timbrado')
def Timbrado():
	URL = request.args['URL'] #Obtiene URL
	User= request.args['User'] #Obtiene USER
	Passw= request.args['Pass'] #Obtiene Pass
	ID= request.args['ID']		#Obtiene ID que hace Ref. Factura Historico
	User_PAC= request.args['UP']
	Password_PAC=request.args['PP']
	URL_PAC=request.args['URLP']
	Key = request.args['Key'] #Obtener la llave! desde JSON como el Certificado
	Passw = Passw.replace('PLUS','+') #Colocar en Request BC el PLUS
	Respuesta =  requests.get(URL+'/'+ID+'/XML', auth=HTTPBasicAuth(User, Passw), verify=False)
	JSON = Respuesta.json()  #Traduce a JSON
	parser = ET.XMLParser(recover=True,encoding='utf-8')
	xdoc = ET.fromstring(JSON['value'].encode('utf-8'),parser=parser)
	xml1 = ET.tostring(xdoc)
	xsl_root = ET.parse(current_app.open_resource('cadenaoriginal_3_3.xslt'))#'cadenaoriginal_3_3.xslt')
	xsl = ET.XSLT(xsl_root)
	cadena_original = xsl(xdoc)
	key = RSA.import_key(open(Key+'.pem','r')) #Busca el ID de la KEY se debe de cambiar por un GET/JSON
	string = str(cadena_original)
	string = string.replace("\n","")
	string = string.replace("\r","")
	string=string.replace('        ','')
	string= string.lstrip()
	string= string.rstrip()
	h = SHA256.new(string)
	signature = pkcs1_15.new(key).sign(h)
	c=base64.b64encode(signature)
	xdoc.attrib['Sello'] = c #Comentado para pruebas
	wsdl= URL_PAC#'https://www.appfacturainteligente.com/WSTimbrado33Test/WSCFDI33.svc?WSDL'
	client = zeep.Client(wsdl=wsdl)
	xml1 = ET.tostring(xdoc)
	xml1=xml1.replace('&#13;','')
	xml1=xml1.replace('&#10;','')
	result = client.service.TimbrarCFDI(User_PAC,Password_PAC,xml1,'Ref') #Peticion a PAC
	cad = '0'
	try:
	    if result.XMLResultado is not None:
	        cad = result.XMLResultado
	    else:
	        cad = result.CodigoRespuesta+','+result.MensajeError
	except:
	    cad = 'Algo salio mal'
	return cad
if __name__ == '__main__':
	app.run(debug=True, port=5000) #run app in debug mode on port 5000