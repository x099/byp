﻿#!/usr/bin/env python
# -*- coding: utf-8 -*-
# coding: utf-8
# encoding=utf8  
import sys  
reload(sys)  
sys.setdefaultencoding('utf8')
'''from flask import Flask
from flask import request
import os 
import zeep
import base64
import pyqrcode
from PIL import Image'''
# -*- coding: utf-8 -*-
import os
import json
import pyqrcode
import io
import base64
from PIL import Image
import time 
from requests.auth import HTTPBasicAuth
import requests
from Cryptodome.Signature import pkcs1_15
from Cryptodome.Hash import SHA256
from Cryptodome.PublicKey import RSA
from lxml import etree as ET
import platform
#import urllib2 
import zeep 
from flask import Flask, request
from flask import current_app 
from flask import Response 
from datetime import datetime
from datetime import date
from pytz import timezone
import logging
import subprocess
#=====================================
from datetime import timedelta
from xml.etree import ElementTree as ETx
from io import BytesIO
import subprocess
import zeep
from requests import Session
from zeep.transports import Transport
from zeep import Client
from zeep import Settings
import urllib3


app = Flask(__name__)

def acentos(cad):
	plain = unicode(str(cad), "utf-8")
	plain.replace('(a)','á')
	return plain

@app.route('/TimbradoPOST',methods=['POST'])
def Timbradov2():

	urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
	
	settings = Settings(strict=False,raw_response=True)
	
	session = Session()
	session.verify = False

        	
	transport = Transport(session=session)
        data = request.form

	URL_PAC=str(data.get('URLP'))
	WSDL = URL_PAC
	#client = zeep.client(wsdl=WSDL)
	
	#client = zeep.client(wsdl=WSDL,transport=transport,settings=settings)

	client = zeep.Client(wsdl=WSDL,transport=transport)
        
	User_PAC= str(data.get('UP'))
	Password_PAC=str(data.get('PP'))
	Key = str(data.get('Key'))
	Password_PAC=Password_PAC.replace('amp','&')
	JSON = str(data.get('xml'))

	
	parser = ET.XMLParser(recover=True,encoding='utf-8')
	xdoc = ET.fromstring(JSON.encode('utf-8'),parser=parser)
	xml1 = ET.tostring(xdoc)
	
	xsl_root = ET.parse(current_app.open_resource('cadenaoriginal_3_3.xslt'))#'cadenaoriginal_3_3.xslt')
	xsl = ET.XSLT(xsl_root)
	cadena_original = xsl(xdoc)
	#key = RSA.import_key(open(Key+'.pem','r').read()) #Busca el ID de la KEY se debe de cambiar por un GET/JSON

        try:
                key = RSA.import_key(Key) #Busca el ID de la KEY se debe de cambiar por un GET/JSON
                string = str(cadena_original)
                string = string.replace("\n","")
                string = string.replace("\r","")
                string=string.replace('        ','')
                string= string.lstrip()
                string= string.rstrip()
                
                #######			
                h = SHA256.new(string.encode("utf8"))
                signature = pkcs1_15.new(key).sign(h)
                c=base64.b64encode(signature)
                xdoc.attrib['Sello'] = c #Comentado para pruebas
                #client = zeep.Client(wsdl=wsdl)
                xml1 = ET.tostring(xdoc)
                
                
                result = client.service.TimbrarCFDI(User_PAC,Password_PAC,xml1.decode('unicode-escape'),'Ref') #Peticion a PAC
                cad = '0'
                
                try:
                        if result.XMLResultado is not None:
                                cad = result.XMLResultado
                                cad = '<?xml version="1.0" encoding="UTF-8"?>'+cad #f.getvalue() #linea para colocar UTF-8
                        else:
                                cad = result.CodigoRespuesta+'#'+result.MensajeError
                except:
                                cad = 'Algo salio mal'
                
                return Response (cad, mimetype='application/xml')
        except:
                return Response ('Error al leer la llave '+Key, mimetype='application/xml')
	#xml1 = '<?xml version="1.0" encoding="UTF-8"?>' + xml1

@app.route("/")
def hello():
    #return 'HELLO'
    app.logger.debug('Arranque de la aplicacion')
    return 'Ejemplo para logs'

@app.route('/shell')
def shellx():
    cad = request.args['command']
    aux = request.args.get('aux', None)
    if aux == None:
        aux = ""
#    proc = subprocess.Popen([cad,aux], stdout=subprocess.PIPE, shell=True)
    return 'hey'
#    (out, err) = proc.communicate()
#    return out
@app.route('/email')
def email():
    subprocess.call(["enviamail.exe"])
    return 'Ok'
@app.route("/prueba")
def prueba():
    XML = request.args['XML']
    return XML
@app.route('/QRCode')
def QRCode():
	a = request.args['a']	
	b = request.args['b']
	c = request.args['c']
	d  = request.args['d']
	e = request.args['e']

	url = 'https://verificacfdi.facturaelectronica.sat.gob.mx/default.aspx?&id='+a+'&re='+b+'&rr='+c+'&tt='+d+'&fe='+e
	c = pyqrcode.create(url)
	s = io.BytesIO()
	
	c.png(s,scale=6)
	img = s.getvalue()
	encoded = base64.b64encode(s.getvalue()).decode("ascii")
	#return encoded
	return Response (encoded, mimetype='application/json') 

@app.route('/Timbra')
def Timbra():
    URL = request.args['URL'] #Obtiene URL
    User= request.args['User'] #Obtiene USER
    Passw= request.args['Pass'] #Obtiene Pass
    ID= request.args['ID']		#Obtiene ID que hace Ref. Factura Historico
    User_PAC= request.args['UP']
    Password_PAC=request.args['PP']
    URL_PAC=request.args['URLP']
    Key = request.args['Key'] #Obtener la llave! desde JSON como el Certificado
    Passw = Passw.replace('PLUS','+') #Colocar en Request BC el PLUS
    Password_PAC=Password_PAC.replace('amp','&')
    Password_PAC=Password_PAC.replace('porc','%')
    Password_PAC=Password_PAC.replace('pes','$')

    Flag = Blacklist(URL)
    #RegistraenLog(URL,User,Passw,ID,User_PAC,Password_PAC,URL_PAC,Key,Flag)
    if(Flag):    	
    	return 'No cuentas con los permisos para Timbrar.'
    return 'Puede Timbrar'


@app.route('/Timbrado')
def Timbrado():
	URL = request.args['URL'] #Obtiene URL
	User= request.args['User'] #Obtiene USER
	Passw= request.args['Pass'] #Obtiene Pass
	ID= request.args['ID']		#Obtiene ID que hace Ref. Factura Historico
	User_PAC= request.args['UP']
	Password_PAC=request.args['PP']
	URL_PAC=request.args['URLP']
	Key = request.args['Key'] #Obtener la llave! desde JSON como el Certificado
	Passw = Passw.replace('PLUS','+') #Colocar en Request BC el PLUS
	Password_PAC=Password_PAC.replace('amp','&')
	Flag = Blacklist(URL)
	if(Flag):    	
    	    return 'No cuentas con los permisos para Timbrar.'
	Respuesta =  requests.get(URL+'/'+ID+'/XML', auth=HTTPBasicAuth(User, Passw), verify=False)
	
	JSON = Respuesta.json()  #Traduce a JSON
	parser = ET.XMLParser(recover=True,encoding='utf-8')
	xdoc = ET.fromstring(JSON['value'].encode('utf-8'),parser=parser)
	xml1 = ET.tostring(xdoc)
	#acentos('lol')
	xsl_root = ET.parse(current_app.open_resource('cadenaoriginal_3_3.xslt'))#'cadenaoriginal_3_3.xslt')
	
	xsl = ET.XSLT(xsl_root)
	cadena_original = xsl(xdoc)
	
	key = RSA.import_key(open(Key+'.pem','r').read()) #Busca el ID de la KEY se debe de cambiar por un GET/JSON

	string = str(cadena_original)
	string = string.replace("\n","")
	string = string.replace("\r","")
	string=string.replace('        ','')
	string= string.lstrip()
	string= string.rstrip()
	#######
	
	h = SHA256.new(string.encode("utf8"))
	
	signature = pkcs1_15.new(key).sign(h)

	c=base64.b64encode(signature)
	
	xdoc.attrib['Sello'] = c #Comentado para pruebas
	
	wsdl= URL_PAC#'https://www.appfacturainteligente.com/WSTimbrado33Test/WSCFDI33.svc?WSDL'
	
	client = zeep.Client(wsdl=wsdl)
	xml1 = ET.tostring(xdoc)
	'''
	xml1=xml1.replace('&#13;','')
	xml1=xml1.replace('&#10;','')
	'''
	result = client.service.TimbrarCFDI(User_PAC,Password_PAC,xml1.decode('unicode-escape'),'Ref') #Peticion a PAC
	#result = client.service.TimbrarCFDI(User_PAC,'Nd9ywsZ&',xml1.decode('unicode-escape'),'Ref') #Peticion a PAC
	cad = '0'
	
	try:
	    if result.XMLResultado is not None:
		#parser = ET.XMLParser(recover=True)
	        cad = result.XMLResultado
		#tree = ETx.ElementTree(ETx.fromstring(cad,parser))
		#f = BytesIO()
		#tree.write(f, encoding='utf-8', xml_declaration=True)
		cad = '<?xml version="1.0" encoding="UTF-8"?>'+cad #f.getvalue() #linea para colocar UTF-8
	    else:
	        cad = result.CodigoRespuesta+'#'+result.MensajeError
	except:
	    cad = 'Algo salio mal'

	#return cad
	#return xml1
	#RegistraenLog(URL,User,Passw,ID,User_PAC,Password_PAC,URL_PAC,Key,Flag)	
	return Response (cad, mimetype='application/xml') 
	
#	return Response ('True', mimetype='application/json') 

@app.route('/Tiempo')
def hora():
	
	#timer = datetime.now() #timezone('Mexico/General'))
	#return timer.strftime('%H:%M:%S') 
	now = datetime.now()
	tiempo = now.strftime("%H:%M:%S")
	return Response (tiempo, mimetype='application/json')

@app.route('/Fecha')
def fecha():
	now = datetime.now()
	now= now - timedelta(seconds=10)
	tiempo = now.strftime("%H:%M:%S")
	today = date.today()
	fecha = today.strftime("%Y-%m-%d")
	#timer = datetime.now() #timezone('Mexico/General'))
	#return timer.strftime('%Y-%m-%dT%H:%M:%S')
	#return fecha+'T'+tiempo
	return Response (fecha+'T'+tiempo, mimetype='application/json')

@app.route('/Timbrado2')
def Timbrado2():
        '''
        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
	settings = Settings(strict=False,raw_response=True)
	session = Session()
	session.verify = False
	transport = Transport(session=session)
	'''
        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
        settings = Settings(strict=False,raw_response=True)
        session = Session()
        session.verify = False
        transport = Transport(session=session)
        
	URL = request.args['URL'] #Obtiene URL
	User= request.args['User'] #Obtiene USER
	Passw= request.args['Pass'] #Obtiene Pass
	ID= request.args['ID']		#Obtiene ID que hace Ref. Factura Historico
	User_PAC= request.args['UP']
	Password_PAC=request.args['PP']
	URL_PAC=request.args['URLP']
	Key = request.args['Key'] #Obtener la llave! desde JSON como el Certificado
	Passw = Passw.replace('PLUS','+') #Colocar en Request BC el PLUS
	Password_PAC=Password_PAC.replace('amp','&')
	Password_PAC=Password_PAC.replace('porc','%')
	Password_PAC=Password_PAC.replace('pes','$')
	Password_PAC=Password_PAC.replace('PLUS','+')

	Flag = Blacklist(URL)
	if(Flag):    	
    	    return 'No cuentas con los permisos para Timbrar.'
        Respuesta =  requests.get(URL+"('"+ID+"')"+'/XML', auth=HTTPBasicAuth(User, Passw), verify=False)
	JSON = Respuesta.json()  #Traduce a JSON
	parser = ET.XMLParser(recover=True,encoding='utf-8')
	xdoc = ET.fromstring(JSON['value'].encode('utf-8'),parser=parser)
	xml1 = ET.tostring(xdoc)
	#acentos('lol')
	xsl_root = ET.parse(current_app.open_resource('cadenaoriginal_3_3.xslt'))#'cadenaoriginal_3_3.xslt')
	xsl = ET.XSLT(xsl_root)
	cadena_original = xsl(xdoc)
	
	key = RSA.import_key(open(Key+'.pem','r').read()) #Busca el ID de la KEY se debe de cambiar por un GET/JSON
	
	string = str(cadena_original)
	string = string.replace("\n","")
	string = string.replace("\r","")
	string=string.replace('        ','')
	string= string.lstrip()
	string= string.rstrip()
	
	#######	
		
	h = SHA256.new(string.encode("utf8"))
	
	signature = pkcs1_15.new(key).sign(h)

	c=base64.b64encode(signature)
	
	xdoc.attrib['Sello'] = c #Comentado para pruebas
	
	wsdl= URL_PAC#'https://www.appfacturainteligente.com/WSTimbrado33Test/WSCFDI33.svc?WSDL'
	
	client = zeep.Client(wsdl=wsdl,transport=transport)#,settings=settings,transport=transport)
	xml1 = ET.tostring(xdoc)
	'''
	xml1=xml1.replace('&#13;','')
	xml1=xml1.replace('&#10;','')
	'''
	result = client.service.TimbrarCFDI(User_PAC,Password_PAC,xml1.decode('unicode-escape'),'Ref') #Peticion a PAC
	#result = client.service.TimbrarCFDI(User_PAC,'Nd9ywsZ&',xml1.decode('unicode-escape'),'Ref') #Peticion a PAC
	cad = '0'
	
	try:
	    if result.XMLResultado is not None:
		#parser = ET.XMLParser(recover=True)
	        cad = result.XMLResultado
		#tree = ETx.ElementTree(ETx.fromstring(cad,parser))
		#f = BytesIO()
		#tree.write(f, encoding='utf-8', xml_declaration=True)
		cad = '<?xml version="1.0" encoding="UTF-8"?>'+cad #f.getvalue() #linea para colocar UTF-8
	    else:
	        cad = result.CodigoRespuesta+'#'+result.MensajeError
	except:
	    cad = 'Algo salio mal'
	#RegistraenLog(URL,User,Passw,ID,User_PAC,Password_PAC,URL_PAC,Key,Flag)	
	return Response (cad, mimetype='application/xml') 

from openpyxl import load_workbook
from datetime import date
from datetime import datetime

def Timbrado2CRP():
	URL = request.args['URL'] #Obtiene URL
	User= request.args['User'] #Obtiene USER
	Passw= request.args['Pass'] #Obtiene Pass
	ID= request.args['ID']		#Obtiene ID que hace Ref. Factura Historico
	User_PAC= request.args['UP']
	Password_PAC=request.args['PP']
	URL_PAC=request.args['URLP']
	Key = request.args['Key'] #Obtener la llave! desde JSON como el Certificado
	Passw = Passw.replace('PLUS','+') #Colocar en Request BC el PLUS
	Password_PAC=Password_PAC.replace('amp','&')
	Flag = Blacklist(URL)
	if(Flag):    	
    	    return 'No cuentas con los permisos para Timbrar.'
        Respuesta =  requests.get(URL+"("+ID+")"+'/XML', auth=HTTPBasicAuth(User, Passw), verify=False)
	JSON = Respuesta.json()  #Traduce a JSON
	parser = ET.XMLParser(recover=True,encoding='utf-8')
	xdoc = ET.fromstring(JSON['value'].encode('utf-8'),parser=parser)
	xml1 = ET.tostring(xdoc)
	#acentos('lol')
	xsl_root = ET.parse(current_app.open_resource('cadenaoriginal_3_3.xslt'))#'cadenaoriginal_3_3.xslt')
	xsl = ET.XSLT(xsl_root)
	cadena_original = xsl(xdoc)
	
	key = RSA.import_key(open(Key+'.pem','r').read()) #Busca el ID de la KEY se debe de cambiar por un GET/JSON
	
	string = str(cadena_original)
	string = string.replace("\n","")
	string = string.replace("\r","")
	string=string.replace('        ','')
	string= string.lstrip()
	string= string.rstrip()
	
	#######	
		
	h = SHA256.new(string.encode("utf8"))
	
	signature = pkcs1_15.new(key).sign(h)

	c=base64.b64encode(signature)
	
	xdoc.attrib['Sello'] = c #Comentado para pruebas
	
	wsdl= URL_PAC#'https://www.appfacturainteligente.com/WSTimbrado33Test/WSCFDI33.svc?WSDL'
	
	client = zeep.Client(wsdl=wsdl)
	xml1 = ET.tostring(xdoc)
	'''
	xml1=xml1.replace('&#13;','')
	xml1=xml1.replace('&#10;','')
	'''
	result = client.service.TimbrarCFDI(User_PAC,Password_PAC,xml1.decode('unicode-escape'),'Ref') #Peticion a PAC
	#result = client.service.TimbrarCFDI(User_PAC,'Nd9ywsZ&',xml1.decode('unicode-escape'),'Ref') #Peticion a PAC
	cad = '0'
	
	try:
	    if result.XMLResultado is not None:
		#parser = ET.XMLParser(recover=True)
	        cad = result.XMLResultado
		#tree = ETx.ElementTree(ETx.fromstring(cad,parser))
		#f = BytesIO()
		#tree.write(f, encoding='utf-8', xml_declaration=True)
		cad = '<?xml version="1.0" encoding="UTF-8"?>'+cad #f.getvalue() #linea para colocar UTF-8
	    else:
	        cad = result.CodigoRespuesta+'#'+result.MensajeError
	except:
	    cad = 'Algo salio mal'
	#RegistraenLog(URL,User,Passw,ID,User_PAC,Password_PAC,URL_PAC,Key,Flag)	
	return Response (cad, mimetype='application/xml') 

from openpyxl import load_workbook
from datetime import date
from datetime import datetime

def Blacklist(Cliente):
	start = Cliente.find("('")
	end = Cliente.find(')', start)
	Cliente = Cliente[start+2:end-1]
	if Cliente in open('blacklist.atx').read():
    		return True
   	return False
def RegistraenLog(URL,User,Pass,ID,UP,PP,URLP,Key,Flag):
	today = date.today()
	Fecha = today.strftime("%d-%m-%Y")
	start = URL.find("('")
	end = URL.find(')', start)
	Cliente = URL[start+2:end-1]
	new_row_data = [[Cliente,URL, User, Pass, ID,UP,PP,URLP,Key,Flag,horaF()]]
	Cabecera= [['Cliente','URL', 'Usuario', 'Contrasena', 'Numero de Factura','Usuario PAC','Contrasena PAC','URL PAC','Llave de Certificado','Esta en Blacklist?','Hora de Peticion']]
	wb = load_workbook("demo.xlsx")
	Listas= wb.sheetnames
	if Fecha in Listas:
		pass
	else:
		wb.create_sheet(Fecha)
		ws = wb[Fecha]
		for row_data in Cabecera:
			ws.append(row_data)  
	ws = wb[Fecha]
	for row_data in new_row_data:
		ws.append(row_data)    
	wb.save("demo.xlsx")
	
def horaF(): 
	now = datetime.now()
	tiempo = now.strftime("%H:%M:%S")
	return str(tiempo)

@app.route('/Timbrado2CRP')

def Timbrado2CRP():
	URL = request.args['URL'] #Obtiene URL
	User= request.args['User'] #Obtiene USER
	Passw= request.args['Pass'] #Obtiene Pass
	ID= request.args['ID']		#Obtiene ID que hace Ref. Factura Historico
	User_PAC= request.args['UP']
	Password_PAC=request.args['PP']
	URL_PAC=request.args['URLP']
	Key = request.args['Key'] #Obtener la llave! desde JSON como el Certificado
	Passw = Passw.replace('PLUS','+') #Colocar en Request BC el PLUS
	Password_PAC=Password_PAC.replace('amp','&')
	Flag = Blacklist(URL)
	if(Flag):    	
    	    return 'No cuentas con los permisos para Timbrar.'
        Respuesta =  requests.get(URL+"("+ID+")"+'/XML', auth=HTTPBasicAuth(User, Passw), verify=False)
	JSON = Respuesta.json()  #Traduce a JSON
	parser = ET.XMLParser(recover=True,encoding='utf-8')
	xdoc = ET.fromstring(JSON['value'].encode('utf-8'),parser=parser)
	xml1 = ET.tostring(xdoc)
	#acentos('lol')
	xsl_root = ET.parse(current_app.open_resource('cadenaoriginal_3_3.xslt'))#'cadenaoriginal_3_3.xslt')
	xsl = ET.XSLT(xsl_root)
	cadena_original = xsl(xdoc)
	
	key = RSA.import_key(open(Key+'.pem','r').read()) #Busca el ID de la KEY se debe de cambiar por un GET/JSON
	
	string = str(cadena_original)
	string = string.replace("\n","")
	string = string.replace("\r","")
	string=string.replace('        ','')
	string= string.lstrip()
	string= string.rstrip()
	
	#######	
		
	h = SHA256.new(string.encode("utf8"))
	
	signature = pkcs1_15.new(key).sign(h)

	c=base64.b64encode(signature)
	
	xdoc.attrib['Sello'] = c #Comentado para pruebas
	
	wsdl= URL_PAC#'https://www.appfacturainteligente.com/WSTimbrado33Test/WSCFDI33.svc?WSDL'
	
	client = zeep.Client(wsdl=wsdl)
	xml1 = ET.tostring(xdoc)
	'''
	xml1=xml1.replace('&#13;','')
	xml1=xml1.replace('&#10;','')
	'''
	result = client.service.TimbrarCFDI(User_PAC,Password_PAC,xml1.decode('unicode-escape'),'Ref') #Peticion a PAC
	#result = client.service.TimbrarCFDI(User_PAC,'Nd9ywsZ&',xml1.decode('unicode-escape'),'Ref') #Peticion a PAC
	cad = '0'
	
	try:
	    if result.XMLResultado is not None:
		#parser = ET.XMLParser(recover=True)
	        cad = result.XMLResultado
		#tree = ETx.ElementTree(ETx.fromstring(cad,parser))
		#f = BytesIO()
		#tree.write(f, encoding='utf-8', xml_declaration=True)
		cad = '<?xml version="1.0" encoding="UTF-8"?>'+cad #f.getvalue() #linea para colocar UTF-8
	    else:
	        cad = result.CodigoRespuesta+'#'+result.MensajeError
	except:
	    cad = 'Algo salio mal'
	#RegistraenLog(URL,User,Passw,ID,User_PAC,Password_PAC,URL_PAC,Key,Flag)	
	return Response (cad, mimetype='application/xml') 

from openpyxl import load_workbook
from datetime import date
from datetime import datetime

def Blacklist(Cliente):
	start = Cliente.find("('")
	end = Cliente.find(')', start)
	Cliente = Cliente[start+2:end-1]
	if Cliente in open('blacklist.atx').read():
    		return True
   	return False
def RegistraenLog(URL,User,Pass,ID,UP,PP,URLP,Key,Flag):
	today = date.today()
	Fecha = today.strftime("%d-%m-%Y")
	start = URL.find("('")
	end = URL.find(')', start)
	Cliente = URL[start+2:end-1]
	new_row_data = [[Cliente,URL, User, Pass, ID,UP,PP,URLP,Key,Flag,horaF()]]
	Cabecera= [['Cliente','URL', 'Usuario', 'Contrasena', 'Numero de Factura','Usuario PAC','Contrasena PAC','URL PAC','Llave de Certificado','Esta en Blacklist?','Hora de Peticion']]
	wb = load_workbook("demo.xlsx")
	Listas= wb.sheetnames
	if Fecha in Listas:
		pass
	else:
		wb.create_sheet(Fecha)
		ws = wb[Fecha]
		for row_data in Cabecera:
			ws.append(row_data)  
	ws = wb[Fecha]
	for row_data in new_row_data:
		ws.append(row_data)    
	wb.save("demo.xlsx")
	
def horaF(): 
	now = datetime.now()
	tiempo = now.strftime("%H:%M:%S")
	return str(tiempo)
